#include "Textures.hpp"
#include "Constants.hpp"
#include <SFML/Graphics.hpp>

namespace textures {
    std::vector<sf::Texture> playerTexture;
    sf::Texture pipeTexture;
    sf::Texture bgTexture;
    sf::Texture gameOverTexture;
    sf::Sprite gameOverSprite;
    sf::Sprite bgSprite;
    sf::Font gameOverFont;

    bool loadPlayerTexture(const std::vector<std::string>& paths)
    {
        playerTexture.resize(paths.size());
        for (int i = 0; i < playerTexture.size(); ++i)
        {
            if (!playerTexture[i].loadFromFile(paths[i])) {return false;}
        }
        return true;
    }
    std::vector<sf::Texture>& getPlayerTexture()
    {
        return playerTexture;
    }
    bool loadPipeTexture(const std::string& path)
    {
        return pipeTexture.loadFromFile(path);
    }
    sf::Texture& getPipeTexture()
    {
        return pipeTexture;
    }
    bool loadBackgroundTexture(const std::string& path)
    {
        if (!bgTexture.loadFromFile(path)) {return false;}
        bgSprite.setTexture(bgTexture);
        float scaleX = WINDOW_WIDTH / bgSprite.getLocalBounds().width;
        float scaleY = WINDOW_HEIGHT / bgSprite.getLocalBounds().height;
        bgSprite.setScale(scaleX, scaleY);
        return true;
    }
    sf::Sprite& getBackgroundTexture()
    {
        return bgSprite;
    }
    bool loadGameOverFont(const std::string& path)
    {
        return gameOverFont.loadFromFile(path);
    }
    sf::Font& getGameOverFont()
    {
        return gameOverFont;
    }
    bool loadGameOverTexture(const std::string& path)
    {
        if (!gameOverTexture.loadFromFile(path)) {return false;}
        gameOverSprite.setTexture(gameOverTexture);
        return true;
    }
    sf::Texture& getGameOverTexture()
    {
        return gameOverTexture;
    }
    sf::Sprite& getGameOverSprite()
    {
        return gameOverSprite;
    }
}