#pragma once
#include "Character.hpp"

class Bird : public Character
{
    private:
        float m_velocity;
        std::vector<sf::Texture> m_animationFrames;
        int m_currentFrame = 0;
        float m_animationTimer = 0.0f;
        float m_frameDuration = 0.1f;
    public:
        Bird() = delete;
        Bird(const std::vector<sf::Texture>& frames, const sf::Vector2f& start_pos);
        void flap();
        Bird(const Bird& player) = delete;
        void update(float time, sf::RenderWindow& window) override;
        void scaling() override;
        void updateAnimation(float time);
};