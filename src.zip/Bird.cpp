#include "Bird.hpp"
#include "Constants.hpp"

Bird::Bird(const std::vector<sf::Texture>& frames, const sf::Vector2f& start_pos) : m_animationFrames(frames)
{
    if (!m_animationFrames.empty()) {o_sprite.setTexture(m_animationFrames[0]);}
    setPos(start_pos);
    scaling();
    auto bounds = getBounds();
    o_sprite.setOrigin(bounds.left + bounds.width / 2.0f, bounds.top + bounds.height / 2.0f);   
    o_sprite.setPosition(start_pos);
    m_velocity = 0.0f;
}
void Bird::flap()
{
    m_velocity = FLAP_STRENGTH;
    m_velocity *= 0.8f;
}
void Bird::update(float time, sf::RenderWindow& window)
{
    m_velocity += GRAVITY * time;
    m_velocity = std::min(m_velocity, MAX_FALL_SPEED);
    sf::Vector2f newpos = getPos();
    newpos.y += m_velocity * time;
    auto bounds = getBounds();
    newpos.y = std::max(bounds.height / 2.0f, std::min(WINDOW_HEIGHT - bounds.height / 2.0f, newpos.y));
    setPos(newpos);
    o_sprite.setPosition(newpos);
    float rotation = m_velocity * ROTATION_FACTOR;
    rotation = std::clamp(rotation, -MAX_ROTATION, MAX_ROTATION);
    o_sprite.setRotation(rotation);
    updateAnimation(time);
}
void Bird::scaling()
{
    o_sprite.setScale(2.0f, 2.0f);
}
void Bird::updateAnimation(float time)
{
    m_animationTimer += time;
    if (m_animationTimer >= m_frameDuration)
    {
        m_animationTimer = 0.0f;
        m_currentFrame = (m_currentFrame + 1) % m_animationFrames.size();
        o_sprite.setTexture(m_animationFrames[m_currentFrame]);
    }
}