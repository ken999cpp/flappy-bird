#pragma once

constexpr float WINDOW_WIDTH = 1920.0f;
constexpr float WINDOW_HEIGHT = 1080.0f;
constexpr float GRAVITY = 2000.0f;
constexpr float FLAP_STRENGTH = -600.0f;
constexpr float MAX_FALL_SPEED = 800.0f;
constexpr float ROTATION_FACTOR = 0.06f;
constexpr float MAX_ROTATION = 30.0f;
constexpr float PIPE_SPEED = 400.0f;
constexpr float PIPE_SPAWN_TIME = 2.0f;
constexpr float PIPE_GAP = 450.0f;