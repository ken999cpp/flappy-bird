#pragma once
#include <SFML/Graphics.hpp>
#include "Character.hpp"

class Pipe : public Character
{
    private:
        bool m_passed = false;
        bool m_top;
    public:
        Pipe() = delete;
        Pipe(sf::Texture& texture, const sf::Vector2f& start_pos, bool top_pipe);
        bool isTop() const;
        bool isOffScreen() const;
        bool isPassed() const;
        void setPassed(bool passed);
        void update(float time, sf::RenderWindow& window) override;
        void scaling() override;
};