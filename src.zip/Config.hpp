#pragma once
#include <string>
#include <vector>

namespace config
{
    const std::vector<std::string> PLAYER_TEXTURE_PATHS = {"assets/textures/characters/bluebird-downflap.png",
        "assets/textures/characters/bluebird-midflap.png","assets/textures/characters/bluebird-upflap.png"};
    const std::string PIPE_TEXTURE_PATH = "assets/textures/characters/pipe-green.png";
    const std::string FONT_PATH = "assets/fonts/RobotoCondensed-VariableFont_wght.ttf";
    const std::string RECORD_PATH = "assets/record/record.txt";
    const std::string BACKGROUND_PATH = "assets/textures/background/background-day.png";
    const std::string AUDIO_WING_PATH = "assets/audio/wing.wav";
    const std::string AUDIO_SWOOSH_PATH = "assets/audio/swoosh.wav";
    const std::string AUDIO_POINT_PATH = "assets/audio/point.wav";
    const std::string AUDIO_HIT_PATH = "assets/audio/hit.wav";
    const std::string AUDIO_DIE_PATH = "assets/audio/die.wav";
    const std::string GAME_OVER_PATH = "assets/textures/gameover/gameover.png";
}