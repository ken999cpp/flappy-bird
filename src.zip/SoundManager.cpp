#include "SoundManager.hpp"
#include "Config.hpp"

sf::SoundBuffer flapBuffer, pointBuffer, hitBuffer, dieBuffer, swooshBuffer;
sf::Sound flapSound, pointSound, hitSound, dieSound, swooshSound;
bool sounds::load()
{
    if (!flapBuffer.loadFromFile(config::AUDIO_WING_PATH)) {return false;}
    if (!pointBuffer.loadFromFile(config::AUDIO_POINT_PATH)) {return false;}
    if (!hitBuffer.loadFromFile(config::AUDIO_HIT_PATH)) {return false;}
    if (!dieBuffer.loadFromFile(config::AUDIO_DIE_PATH)) {return false;}
    if (!swooshBuffer.loadFromFile(config::AUDIO_SWOOSH_PATH)) {return false;}
    flapSound.setBuffer(flapBuffer);
    pointSound.setBuffer(pointBuffer);
    hitSound.setBuffer(hitBuffer);
    dieSound.setBuffer(dieBuffer);
    swooshSound.setBuffer(swooshBuffer);
    return true;
}
void sounds::playFlap() {flapSound.play();}
void sounds::playPoint() {pointSound.play();}
void sounds::playHit() {hitSound.play();}
void sounds::playDie() {dieSound.play();}
void sounds::playSwoosh() {swooshSound.play();}