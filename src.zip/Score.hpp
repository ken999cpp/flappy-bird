#pragma once
#include <SFML/Graphics.hpp>
#include "Textures.hpp"

sf::Text scoreText;
void setupScore()
{
    scoreText.setFont(textures::getGameOverFont());
    scoreText.setCharacterSize(24);
    scoreText.setFillColor(sf::Color::White);
    scoreText.setPosition(10, 10);
}