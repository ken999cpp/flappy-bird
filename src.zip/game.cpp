#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include "Bird.hpp"
#include "Pipe.hpp"
#include "Textures.hpp"
#include "SoundManager.hpp"
#include "Constants.hpp"
#include "Config.hpp"
#include "Score.hpp"
#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>

int main()
{
    sf::RenderWindow window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Flappy Bird");
    std::srand(static_cast<unsigned>(std::time(nullptr)));
    if (!textures::loadPlayerTexture(config::PLAYER_TEXTURE_PATHS))
    {
        std::cerr << "Failed to load player texture\n";
        return -1;
    }
    if (!textures::loadPipeTexture(config::PIPE_TEXTURE_PATH))
    {
        std::cerr << "Failed to load stone texture\n";
        return -1;
    }
    if (!textures::loadGameOverFont(config::FONT_PATH))
    {
        std::cerr << "Failed to load font\n";
        return -1;
    }
    if (!textures::loadBackgroundTexture(config::BACKGROUND_PATH))
    {
        std::cerr << "Failed to load background\n";
        return -1;
    }
    if (!textures::loadGameOverTexture(config::GAME_OVER_PATH))
    {
        std::cerr << "Failed to load game over texture";
        return -1;
    }
    if (!sounds::load())
    {
        std::cerr << "Failed to load sounds\n";
        return -1;
    }
    setupScore();
    Bird* bird = new Bird(textures::getPlayerTexture(), {WINDOW_WIDTH / 3.0f, WINDOW_HEIGHT / 2.0f});
    std::vector<Pipe*> pipes;
    sf::Clock clock, pipeSpawnClock;
    int score = 0;
    bool game_over = false, game_over_drawn = false;
    while (window.isOpen())
    {
        float time = clock.restart().asSeconds();
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Space && !game_over)
            {
                bird -> flap();
                sounds::playFlap();
            }
            if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::R && game_over)
            {
                delete bird;
                bird = new Bird(textures::getPlayerTexture(), {WINDOW_WIDTH / 3.0f, WINDOW_HEIGHT / 2.0f});
                for (auto& pipe : pipes) {delete pipe;}
                pipes.clear();
                score = 0;
                game_over = false;
                game_over_drawn = false;
                sounds::playSwoosh();
            }
        }
        if (!game_over)
        {
            if (pipeSpawnClock.getElapsedTime().asSeconds() > PIPE_SPAWN_TIME)
            {
                float rand_height = static_cast<float>(std::rand() % 200 + 100);
                float pipe_height = textures::getPipeTexture().getSize().y;
                pipes.push_back(new Pipe(textures::getPipeTexture(), {WINDOW_WIDTH, WINDOW_HEIGHT - rand_height - pipe_height}, false));
                pipes.push_back(new Pipe(textures::getPipeTexture(), {WINDOW_WIDTH, rand_height - PIPE_GAP - pipe_height}, true));
                pipeSpawnClock.restart();
            }
            bird -> update(time, window);
            for (auto& pipe : pipes)
            {
                pipe -> update(time, window);
                if (bird -> getBounds().intersects(pipe -> getBounds())) {game_over = true;}
                if (!pipe -> isPassed() && (pipe -> getBounds().left + pipe -> getBounds().width) < bird -> getBounds().left
                && !pipe -> isTop())
                {
                    pipe -> setPassed(true);
                    score++;
                    sounds::playPoint();
                }
            }
            pipes.erase(std::remove_if(pipes.begin(), pipes.end(),
            [](Pipe* p)
            {
                bool rm = p -> isOffScreen();
                if (rm) {delete p;}
                return rm;
            }),     pipes.end());
        }
        window.clear();
        window.draw(textures::getBackgroundTexture());
        window.draw(bird -> getSprite());
        for (auto& pipe : pipes) {window.draw(pipe -> getSprite());}
        scoreText.setString(std::to_string(score));
        window.draw(scoreText);
        if (game_over)
        {   
            sounds::playDie();
            sf::FloatRect spriteBounds = textures::getGameOverSprite().getLocalBounds();
            textures::getGameOverSprite().setOrigin(spriteBounds.width / 2.f, spriteBounds.height / 2.f);
            textures::getGameOverSprite().setPosition(window.getSize().x / 2.f, window.getSize().y / 2.f); 
            window.draw(textures::getGameOverSprite());
        }
        window.display();
    }
    delete bird;
    for (auto& pipe : pipes) {delete pipe;}
    return 0;
}