#pragma once
#include <SFML/Graphics.hpp>

namespace textures {
    bool loadPlayerTexture(const std::vector<std::string>& paths);
    std::vector<sf::Texture>& getPlayerTexture();
    bool loadPipeTexture(const std::string& path);
    sf::Texture& getPipeTexture();
    bool loadBackgroundTexture(const std::string& path);
    sf::Sprite& getBackgroundTexture();
    bool loadGameOverFont(const std::string& path);
    sf::Font& getGameOverFont();
    bool loadGameOverTexture(const std::string& path);
    sf::Texture& getGameOverTexture();
    sf::Sprite& getGameOverSprite();
}