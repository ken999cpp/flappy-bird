#include "Pipe.hpp"
#include "Constants.hpp"

Pipe::Pipe(sf::Texture& texture, const sf::Vector2f& start_pos, bool top_pipe) : m_top(top_pipe)
{
    setSpeed(PIPE_SPEED);
    o_sprite.setTexture(texture);
    setPos(start_pos);
    o_sprite.setPosition(start_pos);
    if (top_pipe)
    {
        auto bounds = o_sprite.getLocalBounds();
        o_sprite.setOrigin(0.f, bounds.height);
        o_sprite.setScale(1.f, -1.f);
    }
    scaling();
    m_passed = false;
}
bool Pipe::isTop() const
{
    return m_top;
}
bool Pipe::isOffScreen() const
{
    return getSprite().getPosition().x < -100.0f;
}
bool Pipe::isPassed() const
{
    return m_passed;
}
void Pipe::setPassed(bool passed)
{
    m_passed = passed;
}
void Pipe::update(float time, sf::RenderWindow& window)
{
    o_sprite.move(-getSpeed() * time, 0);
}
void Pipe::scaling()
{
    if (isTop()) {o_sprite.setScale(2.5f, -2.5f);}
    else {o_sprite.setScale(2.5f, 2.5f);}
}