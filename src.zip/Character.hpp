#pragma once
#include <SFML/Graphics.hpp>

class Character
{
    protected:
        sf::Vector2f o_pos;
        sf::Sprite o_sprite;
        float o_speed = 0.0f;
    public:
        virtual ~Character() = 0;
        virtual void setPos(const sf::Vector2f& position);
        virtual const sf::Vector2f& getPos() const;
        virtual void setSpeed(float speed);
        virtual float getSpeed() const;
        virtual const sf::Sprite& getSprite() const;
        virtual void setSprite();
        virtual void update(float time, sf::RenderWindow& window) = 0;
        virtual void scaling() = 0;
        virtual sf::FloatRect getBounds();
};