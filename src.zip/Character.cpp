#include "Character.hpp"
Character::~Character() {}
const sf::Sprite& Character::getSprite() const
{
    return o_sprite;
}
void Character::setSprite()
{
    o_sprite.setPosition(o_pos);
}
void Character::setPos(const sf::Vector2f& position)
{
    o_pos = position;
}
const sf::Vector2f& Character::getPos() const
{
    return o_pos;
}
void Character::setSpeed(float speed)
{
    o_speed = speed;
}
float Character::getSpeed() const
{
    return o_speed;
}
sf::FloatRect Character::getBounds()
{
    return o_sprite.getGlobalBounds();
}