#pragma once
#include <SFML/Audio.hpp>
namespace sounds
{
    bool load();
    void playFlap();
    void playPoint();
    void playHit();
    void playDie();
    void playSwoosh();
}